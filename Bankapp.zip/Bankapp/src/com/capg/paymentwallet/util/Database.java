package com.capg.paymentwallet.util;

import java.util.ArrayList;
import java.util.List;

public class Database 
{
	static List<String> operations = new ArrayList<>();
	public static List<String> getOperations()
	{
		operations.add( "Create account");
		operations.add( "Show Balance");
		operations.add( "Deposit");
		operations.add( "Withdraw");
		operations.add( "FundTransfer");
		operations.add( "Print Transactions");
		operations.add( "Exit");
		
		return operations;
	}

}