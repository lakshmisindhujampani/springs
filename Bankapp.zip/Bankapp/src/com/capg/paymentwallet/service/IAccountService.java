package com.capg.paymentwallet.service;
import java.util.List;

import com.capg.paymentwallet.bean.AccountBean;
import com.capg.paymentwallet.exception.CustomerException;

public interface IAccountService {
	public boolean createAccount(AccountBean accountBean) throws CustomerException;

	public AccountBean findAccount(int accountId) throws CustomerException;

	public boolean deposit(AccountBean accountBean, double depositAmount) throws CustomerException;

	public boolean withdraw(AccountBean accountBean, double withdrawAmount) throws CustomerException;

	public boolean fundTransfer(AccountBean transferingAccountBean,
			AccountBean beneficiaryAccountBean, double transferAmount) throws CustomerException;

	public List<String> getOperations();
	 
    

}
